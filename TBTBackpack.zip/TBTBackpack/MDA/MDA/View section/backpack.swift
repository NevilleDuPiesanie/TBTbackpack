

import SwiftUI

struct backpack: View {
    @StateObject var expenses = allStoredItems()
    @State private var showingAddExpense = false

    var body: some View {
        NavigationView {
            List {
                ForEach(expenses.items) { item in
                    HStack {
                        VStack(alignment: .leading) {
                            Text(item.name)
                                .font(.headline)
                        }

                        Spacer()
                        Text("Quantity: \(item.amount)")
                    }
                }
                .onDelete(perform: removeItems)
            }
            .navigationTitle("Items")
            .navigationBarItems(trailing: EditButton())
            .toolbar {
                Button {
                    showingAddExpense = true
                } label: {
                    Image(systemName: "plus")
                }
            }
            .sheet(isPresented: $showingAddExpense) {
                AddView(allItems: expenses)
            }
        }
    }

    func removeItems(at offsets: IndexSet) {
        expenses.items.remove(atOffsets: offsets)
    }
}


struct backpack_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
