

import SwiftUI

enum CalcButton: String {
    case one = "1"
    case two = "2"
    case three = "3"
    case four = "4"
    case five = "5"
    case six = "6"
    case seven = "7"
    case eight = "8"
    case nine = "9"
    case zero = "0"
    case add = "+"
    case subtract = "-"
    case divide = "÷"
    case mutliply = "*"
    case equal = "="
    case clear = "C"


    var btnColor: Color {
        return Color(.white)
    }
}


enum Operation {
    case add, subtract, multiply, divide, none
}

struct calculator: View {

    @State var value = "0"
    @State var runningNumber = 0
    @State var currentOperation: Operation = .none

    let buttons: [[CalcButton]] = [
        [.clear, .divide],
        [.seven, .eight, .nine, .mutliply],
        [.four, .five, .six, .subtract],
        [.one, .two, .three, .add],
        [.zero, .equal],
    ]

    //handling most of the button format (template used to mimic standard Iphone calculator
    var body: some View {
        ZStack {
            Color.white.cornerRadius(5)
            VStack {
                Spacer()

                HStack {
                    Spacer()
                    Text(value)
                        .bold()
                        .font(.system(size: 50))
                        .foregroundColor(.black)
                    
                    
                }
                .padding()
                
                ForEach(buttons, id: \.self) { row in
                    HStack(spacing: 60) {
                        ForEach(row, id: \.self) { item in
                            Button(action: {
                                self.ifClicked(button: item)
                            }, label: {
                                
                                Text(item.rawValue)
                                    .font(.system(size: 45))
                                    .cornerRadius(100)
                                    .background(item.btnColor)
                                    .foregroundColor(.black)
                                
                            })
                        }
                    }
                    .padding(.bottom, 3)
                }
            }
        }
    }

    func ifClicked(button: CalcButton) {
        switch button {
        case .add, .subtract, .mutliply, .divide, .equal:
            if button == .add {
                self.currentOperation = .add
                self.runningNumber = Int(self.value) ?? 0
            }
            else if button == .subtract {
                self.currentOperation = .subtract
                self.runningNumber = Int(self.value) ?? 0
            }
            else if button == .mutliply {
                self.currentOperation = .multiply
                self.runningNumber = Int(self.value) ?? 0
            }
            else if button == .divide {
                self.currentOperation = .divide
                self.runningNumber = Int(self.value) ?? 0
            }
            else if button == .equal {
                let runningValue = self.runningNumber
                let currentValue = Int(self.value) ?? 0
                switch self.currentOperation {
                case .add: self.value = "\(runningValue + currentValue)"
                case .subtract: self.value = "\(runningValue - currentValue)"
                case .multiply: self.value = "\(runningValue * currentValue)"
                case .divide: self.value = "\(runningValue / currentValue)"
                case .none:
                    break
                }
            }

            if button != .equal {
                self.value = "0"
            }
        case .clear:
            self.value = "0"
            break
        default:
            let number = button.rawValue
            if self.value == "0" {
                value = number
            }
            else {
                self.value = "\(self.value)\(number)"
            }
        }
    }


}
