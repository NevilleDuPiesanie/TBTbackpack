

import SwiftUI

struct ContentView: View {
    @State private var showingPopover = false
    @State private var showingPopover1 = false
    @State private var showingPopover2 = false
    @State private var showingPopover3 = false
    
    var body: some View {
 
            backpack()
     
                
                    
                       VStack(alignment: .leading) {
                      

                          
                               Button("Show Menu") {
                                        showingPopover = true
                                    }
                                    .popover(isPresented: $showingPopover) {
                                        
                                        VStack{
                                            
                                       Divider()
                                                DiceRoll()
                                            
                                            Divider()
                                            DiceRoll_2___20()
                                           
                                            Divider()
                                            DiceRoll_3___10()
                                            
                                            
                                        }
                                        VStack{
                                           
                                            Divider()
                                            DiceRoll_4___8()
                                            
                                            Divider()
                                            DiceRoll_5___6()
                                            
                                            Divider()
                                            DiceRoll_6___4()
                                            
                                        }

                                    } .modifier(buttonModifier())
                
                       }
                       
                       
                 Divider()
  

                   
                              CoinFlip()
            .modifier(buttonModifier())

                       
                       
              Divider()

                      

        

                                   Button("CheckList") {
                                            showingPopover2 = true
                                        }
                                        .popover(isPresented: $showingPopover2) {
                                            CheckList()
                                            Text("Checklist/Tasklist")
                                                .font(.title)
                                                .padding()
                                                .font(.title)
                                        }
                                        .modifier(buttonModifier())
 
        
              Divider()
                     

                              
                                   Button("Calculator") {
                                            showingPopover3 = true
                                        }
                                        .popover(isPresented: $showingPopover3) {
                                            calculator()

                                        }

                                        .modifier(buttonModifier())
                           

                      
                   }
               }
           


