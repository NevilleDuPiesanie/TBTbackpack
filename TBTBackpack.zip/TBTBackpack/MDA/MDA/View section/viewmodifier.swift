
import SwiftUI

struct buttonModifier: ViewModifier {
    func body(content: Content) -> some View {
        return content
            .foregroundColor(.black)
            //.background(Color(red:221/255,green:217/255,blue:126/255))
            .font(.title)
          
        
    }
}

