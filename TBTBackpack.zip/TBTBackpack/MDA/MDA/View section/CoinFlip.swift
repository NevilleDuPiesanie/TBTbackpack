

import SwiftUI

struct CoinFlip: View {
    @State private var coinVar = "circle.fill"
    var body: some View {
        HStack{
            Text("Flip The Coin:   ")
        Button(action:{
            let coinRandomVar = Int.random(in: 1...2)
            if coinRandomVar == 1 {coinVar = "circle.dashed"}
            else {coinVar = "h.circle.fill"}
        }, label: {
            
            Image(systemName: coinVar)
                .padding()
                .border(.black)
                .cornerRadius(100)
                .modifier(buttonModifier())
                
            })
        }
    
    }
}


