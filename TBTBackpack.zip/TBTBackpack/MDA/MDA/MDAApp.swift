

import SwiftUI

@main
struct MDAApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
           
        }
    }
}
