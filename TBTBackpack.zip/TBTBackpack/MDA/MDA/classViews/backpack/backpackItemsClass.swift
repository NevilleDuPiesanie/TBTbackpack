

import Foundation

struct backpackItem: Identifiable, Codable {
    var id = UUID()
    let name: String
    let amount: Int
}
