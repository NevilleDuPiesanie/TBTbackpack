


import SwiftUI

struct AddView: View {
    @ObservedObject var allItems: allStoredItems
    @Environment(\.dismiss) var dismiss

    @State private var name = ""
    @State private var amount = 0

 

    var body: some View {
        NavigationView {
            Form {
                TextField("Name", text: $name)
                TextField("Amount", value: $amount, format: .number)
                    .keyboardType(.decimalPad)
            }
            .navigationTitle("Place an Item in the bag")
            .toolbar {
                Button("Save") {
                    let item = backpackItem(name: name, amount: amount)
                    allItems.items.append(item)
                    dismiss()
                }
            }
        }
    }
}

struct AddView_Previews: PreviewProvider {
    static var previews: some View {
        AddView(allItems: allStoredItems())
    }
}
