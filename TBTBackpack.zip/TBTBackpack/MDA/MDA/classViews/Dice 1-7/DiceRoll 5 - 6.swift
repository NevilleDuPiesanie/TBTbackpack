

import SwiftUI

struct DiceRoll_5___6: View {
    @State private var DiceResult = "0"
    var body: some View {
        HStack{
        Text("D6")
        
        Button(action:{
            let DiceRoll = Int.random(in: 1...6)
            DiceResult = String(DiceRoll)
        }, label: {
                
            Text(DiceResult)
                .padding()
                .border(.blue)
        
                
            })
        }
    
    }
}
