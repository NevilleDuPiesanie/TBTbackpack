

import SwiftUI

struct DiceRoll_3___10: View {
    @State private var DiceResult = "0"
    var body: some View {
        HStack{
        Text("D10")
        
        Button(action:{
            let DiceRoll = Int.random(in: 1...10)
            DiceResult = String(DiceRoll)
        }, label: {
                
            Text(DiceResult)
                .padding()
                .border(.blue)
        
                
            })
        }
    
    }
}

