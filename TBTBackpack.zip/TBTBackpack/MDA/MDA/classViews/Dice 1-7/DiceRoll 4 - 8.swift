

import SwiftUI

struct DiceRoll_4___8: View {
    @State private var DiceResult = "0"
    var body: some View {
        HStack{
        Text("D8")
        
        Button(action:{
            let DiceRoll = Int.random(in: 1...8)
            DiceResult = String(DiceRoll)
        }, label: {
                
            Text(DiceResult)
                .padding()
                .border(.blue)
        
                
            })
 
        }
    
    }
}
