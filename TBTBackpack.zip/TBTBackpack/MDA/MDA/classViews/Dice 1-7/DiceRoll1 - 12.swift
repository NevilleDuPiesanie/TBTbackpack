
import SwiftUI

struct DiceRoll: View {
    @State private var DiceResult = "0"
    var body: some View {
        HStack{
        Text("D12")
        
        Button(action:{
            let DiceRoll = Int.random(in: 1...12)
            DiceResult = String(DiceRoll)
        }, label: {
                
            Text(DiceResult)
                .padding()
                .border(.blue)
        
                
            })

        }
    
    }
}


