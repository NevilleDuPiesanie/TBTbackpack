

import SwiftUI

struct DiceRoll_2___20: View {
    @State private var DiceResult = "0"
    var body: some View {
        HStack{
        Text("D20")
        
        Button(action:{
            let DiceRoll = Int.random(in: 1...20)
            DiceResult = String(DiceRoll)
        }, label: {
                
            Text(DiceResult)
                .padding()
                .border(.blue)
        
                
            })
        }
    
    }
}


